# CPE 400 Final Project

This is the Python source file for our simulator and agents.

To run this code simply choose and agent file (currently we have Q learning and SARSA) and run:
"""
python do_TYPE_learning.py
"""
so for instance, to run the Q learning agent, type
"""
python do_q_learning.py
"""
in this directory.


The agent's performance is written to the console.

To find out more about the simulator environment, see main.py or our github repo:
https://github.com/Duncanswilson/q-routing-protocol 
